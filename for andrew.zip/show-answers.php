<?php
session_start();
echo $_SESSION['answer1'];
echo "<br>";
echo $_SESSION['answer2'];
echo "<br>";
echo $_SESSION['answer3'];
echo "<br>";
echo $_SESSION['answer4'];
echo "<br>";
echo $_SESSION['answer4b'];
echo "<br>";
echo $_SESSION['answer5'];
?>