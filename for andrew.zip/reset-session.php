<?php
session_start();
session_unset();
echo "session has been reset.";
?>